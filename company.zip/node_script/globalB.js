const A = require('./globalA');

global.message = 'hi hello';
console.log(A());