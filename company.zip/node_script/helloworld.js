function helloworld() {
    console.log("hello world");
    hellonode();
}

function hellonode() {
    console.log("hello node");
}

helloworld();

console.log(__filename);
console.log(__dirname);
