const http = require('http');

// node 기본 웹서버 시작 (3000번 포트)
http.createServer( (request, response) => {
    response.writeHead(200, {'Content-Type' : 'text/plain'})
    response.write("hello server");
    response.end();
}).listen(3000);
